import click
# from system_config import *


@click.command()
@click.argument('command', default="login")

def main(command):
    if command == "login":
        print("login")
    elif command == "volunteer":
        print("Volunteer")


if __name__ == '__main__':
    main()