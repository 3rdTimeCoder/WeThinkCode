import os
import click
import json
from get_username import get_username
# from myCal import return_email, main
import myCal


@click.command()
@click.option('--volunteer', '-v', help="Volunter For A Time Slot")
def volunteer():
    print("Hello World")

def main():
    login()


# @click.command()
def login():
        username,email = get_user_details()
        clear_terminal()
        # set_calendar_access_rule(email)
        output(username, f"Hello!!! Welcome To CodeClinic!\n")
        myCal.main(username)
        

def output(username, message):
    click.echo(f"\n{get_output_prefx(username)}{message}")
    

def get_output_prefx(username):
    user_type_terminal_str = bold_green(f"({username})")
    jhb19 = bold_blue("jhb19")
    return f"\n{user_type_terminal_str}{jhb19}: "
    
    
def get_user_details():
    
    if os.path.exists('.userconfig.json'):
        file = open('.userconfig.json', 'r')
        file_content = json.loads(file.read())
        file.close()
        
        username = file_content["username"]
        email = file_content["email"]
        
        return username , email
    else:
        username = get_username()
        email = myCal.return_email(username)
        user_info = {
            "username" : username,
            "email" : email  
        }
        file = open('.userconfig.json', 'w')
        json.dump(user_info, file, indent=2)
        file.close()
        return username , email
    
        
def bold_blue(string):
    return click.style(string, fg='blue', bold=True)


def bold_green(string):
    return click.style(string, fg='green', bold=True)


def clear_terminal():
    os.system('clear')



if __name__ == '__main__':
    main()