f = open('.rep.txt')
print(f.read())
f.close()