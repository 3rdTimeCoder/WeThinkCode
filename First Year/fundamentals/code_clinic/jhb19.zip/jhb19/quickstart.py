from __future__ import print_function

import datetime
import os.path

from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

# If modifying these scopes, delete the file token.json.
SCOPES = ['https://www.googleapis.com/auth/calendar.readonly',
          'https://www.googleapis.com/auth/calendar' ]


def main():
    """Shows basic usage of the Google Calendar API.
    Prints the start and name of the next 10 events on the user's calendar.
    """
    creds = None
    # The file token.json stores the user's access and refresh tokens, and is
    # created automatically when the authorization flow completes for the first
    # time.
    if os.path.exists('token.json'):
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)
    # If there are no (valid) credentials available, let the user log in.
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                'credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)
        # Save the credentials for the next run
        with open('token.json', 'w') as token:
            token.write(creds.to_json())

    try:
        service = build('calendar', 'v3', credentials=creds)

        # Call the Calendar API
        # now = datetime.datetime.utcnow().isoformat() + 'Z'  # 'Z' indicates UTC time
        # print('Getting the upcoming 10 events')
        # events_result = service.events().list(calendarId='primary', timeMin=now,
        #                                       maxResults=7, singleEvents=True,
        #                                       orderBy='startTime').execute()
        # events = events_result.get('items', [])

        # if not events:
        #     print('No upcoming events found.')
        #     return

        # # Prints the start and name of the next 7 events
        # for event in events:
        #     start = event['start'].get('dateTime', event['start'].get('date'))
        #     print(start)
        #     print(event['summary'])
        #     print(event['attendees'])
        #     print(f"event_id: {event['id']}")
        #     print()
        
        # Create event
        # event = {
        # 'summary': 'Unavailble session',
        # 'location': '800 Howard St., San Francisco, CA 94103',
        # 'description': 'Function, Loops, etc.',
        # 'start': {
        #     'dateTime': '2023-01-20T09:00:00-07:00',
        #     'timeZone': 'America/Los_Angeles',
        # },
        # 'end': {
        #     'dateTime': '2023-01-20T17:00:00-07:00',
        #     'timeZone': 'America/Los_Angeles',
        # },
        # 'recurrence': [
        #     'RRULE:FREQ=DAILY;COUNT=1'
        # ],
        # 'attendees': [
        #     {'email': 'nosifan022@student.wethinkcode.co.za'},
        #     {'email': '4thtimecoder@gmail.com'},
        # ],
        # 'reminders': {
        #     'useDefault': False,
        #     'overrides': [
        #     {'method': 'email', 'minutes': 24 * 60},
        #     {'method': 'popup', 'minutes': 10},
        #     ],
        # },
        # }

        # event = service.events().insert(calendarId='primary', body=event).execute()
        # print('Event created:', event.get('htmlLink'))

        # update event
        # event_id = "b8r9elqh7009g9oqiajemilq68_20230120T160000Z"
        # # First retrieve the event from the API.
        # event = service.events().get(calendarId='primary', eventId=event_id).execute()

        # # print(event)
        # event['summary'] = 'Availble session'

        # # remove student from attendees
        # for obj in event['attendees']:
        #     if '4thtimecoder@gmail.com' in obj.values():
        #         event['attendees'].remove(obj)
        
        # # remove student description
        # event['description'] = 'Tutoring session'

        # # print()
        # # print(event)

        # # update event
        # updated_event = service.events().update(calendarId='primary', eventId=event['id'], body=event).execute()

        # # Print the updated date.
        # print(updated_event['updated'])

        # calendar = {
        #     'summary': 'codeClinic',
        #     'timeZone': 'Africa/Johannesburg' #figure out this timezone shit.
        # }

        # created_calendar = service.calendars().insert(body=calendar).execute()

        # print(created_calendar['id'])
        # calendar_id = "29efaqlfsnv9s7n6d2e008n9l4@group.calendar.google.com"

        # To insert existing calendar:
        # calendar_list_entry = {
        #     'id': 'jhb19.wethinkcode@gmail.com'
        # }

        # created_calendar_list_entry = service.calendarList().insert(body=calendar_list_entry).execute()

        # print(created_calendar_list_entry['summary'])
        
        # acl = service.acl().list(calendarId='primary').execute()

        # for rule in acl['items']:
        #     print(f"{rule['id']}: {rule['role']}" )
        
        rule = {
            'scope': {
                'type': 'group',
                'value': '@wethinkcode.co.za',
            },
            'role': 'writer'
        }

        created_rule = service.acl().insert(calendarId='primary', body=rule).execute()

        print(created_rule['id'])



    except HttpError as error:
        print('An error occurred: %s' % error)


if __name__ == '__main__':
    main()
